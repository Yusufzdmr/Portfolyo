# 🌐 Kişisel Portföy Sitesi

Bu proje, web geliştirme becerilerimi sergilemek için oluşturduğum kişisel portföy sitesidir.  
HTML, CSS ve JavaScript kullanılarak geliştirilmiştir.

## 🚀 Özellikler
- 📄 Hakkımda, Projeler, İletişim bölümleri
- 📱 Mobil uyumlu responsive tasarım
- ⚡ Hızlı yüklenme & sade arayüz

## 🛠 Kullanılan Teknolojiler
- HTML5
- CSS3 (Flexbox / Grid)
- JavaScript (Vanilla)

## 🌍 Canlı Önizleme
[Portföyümü Görüntüle](https://kullanici-adi.github.io/portfolio-site/)

---
✨ Yusuf Özdemir tarafından geliştirilmiştir.